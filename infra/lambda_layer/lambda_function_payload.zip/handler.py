def soma(event, context):
    return 1 + 1